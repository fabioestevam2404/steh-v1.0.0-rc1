# STEH Alpha 0.2

Software Trust Engineering Harness.

## Workflow

```text
FastAPI
  -> Requirements Agent
  -> Requirements Gate
  -> Architecture Agent
  -> Architecture Gate
  -> PostgreSQL (tasks, agent_runs, audit_events)
```

## Run

```bash
cp .env.example .env
docker compose up --build
```

Use `LLM_MODE=stub` for local execution without an API key.

Endpoints:
- `GET /health`
- `POST /api/v1/tasks`
- `GET /api/v1/tasks/{task_id}`
- `GET /api/v1/tasks/{task_id}/audit`

Alpha 0.2 intentionally does not expose shell, host access, arbitrary file writes, or execution-capable tools.
