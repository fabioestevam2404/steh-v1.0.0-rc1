# STEH Alpha 0.1

**Software Trust Engineering Harness**

Primeiro vertical slice executável do STEH: API FastAPI → LangGraph → Requirements Agent → PostgreSQL.

## O que esta versão faz

```text
POST /api/v1/tasks
        |
        v
   FastAPI API
        |
        v
   LangGraph
        |
        v
Requirements Agent
        |
        v
 PostgreSQL
        |
        v
   Task result
```

O Requirements Agent usa um LLM quando `LLM_MODE=openai` e `OPENAI_API_KEY` estão configurados. Para testes locais sem API key, `LLM_MODE=stub` usa uma implementação determinística. O stub existe apenas para desenvolvimento/testes.

## Stack

- Python 3.12+
- FastAPI
- Pydantic v2
- SQLAlchemy 2
- PostgreSQL
- LangGraph
- LangGraph PostgreSQL checkpointer
- OpenAI via `langchain-openai`
- Pytest
- Ruff
- Mypy
- Docker Compose

## Executar

```bash
cp .env.example .env
docker compose up --build
```

A API estará em:

- http://localhost:8000
- http://localhost:8000/docs
- http://localhost:8000/health

Para LLM real:

```dotenv
LLM_MODE=openai
OPENAI_API_KEY=your_key_here
LLM_MODEL=gpt-5-mini
```

Para smoke test sem API key:

```dotenv
LLM_MODE=stub
```

## Criar uma task

```bash
curl -X POST "http://localhost:8000/api/v1/tasks" \
  -H "Content-Type: application/json" \
  -d '{"request":"Crie uma API REST para cadastro e consulta de clientes, com validação e critérios de aceitação."}'
```

## Consultar uma task

```bash
curl "http://localhost:8000/api/v1/tasks/<TASK_ID>"
```

## Testes

```bash
docker compose run --rm api pytest -q
```

Ou localmente:

```bash
pytest -q
ruff check .
ruff format --check .
mypy app
```

## Segurança do Alpha 0.1

O agente ainda **não** possui shell, acesso ao host, escrita arbitrária em repositórios ou execução de ferramentas. Isso é deliberado.

Primeiro estabelecemos contratos, estado, persistência e observabilidade. O sandbox e o Implementation Agent entrarão posteriormente.

## Evolução

- Alpha 0.2 — Architecture Agent
- Alpha 0.3 — Security Agent
- Alpha 0.4 — Implementation Agent + sandbox
- Alpha 0.5 — Test Agent
- Alpha 0.6 — Policy Engine
- Alpha 0.7 — Rework Loop
- MVP 1.0 — Harness completo
