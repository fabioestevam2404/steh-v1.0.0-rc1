from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db.models import TaskRecord
from app.db.session import get_db
from app.models.contracts import TaskCreate, TaskResponse, TaskStatus, ids, utc_now
from app.services.tasks import execute_task
from app.services.audit import record_event, get_task_audit

router = APIRouter(prefix="/api/v1/tasks", tags=["tasks"])

def response(record):
    return TaskResponse(
        task_id=record.task_id, trace_id=record.trace_id, status=TaskStatus(record.status),
        requirements=record.requirements, architecture=record.architecture, created_at=record.created_at
    )

@router.post("", response_model=TaskResponse, status_code=status.HTTP_201_CREATED)
def create_task(payload: TaskCreate, db: Session = Depends(get_db)):
    task_id, trace_id = ids()
    record = TaskRecord(task_id=task_id, trace_id=trace_id, request=payload.request, status=TaskStatus.CREATED, created_at=utc_now(), updated_at=utc_now())
    db.add(record); db.commit()
    record_event(db, task_id, trace_id, "TASK_CREATED", "api", {"request_length":len(payload.request)})
    try:
        return response(execute_task(db, task_id, trace_id, payload))
    except Exception as exc:
        record.status = TaskStatus.FAILED
        db.commit()
        record_event(db, task_id, trace_id, "TASK_FAILED", "orchestrator", {"error_type":type(exc).__name__})
        raise HTTPException(status_code=500, detail="Task execution failed") from exc

@router.get("/{task_id}", response_model=TaskResponse)
def get_task(task_id: UUID, db: Session = Depends(get_db)):
    record = db.get(TaskRecord, task_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return response(record)

@router.get("/{task_id}/audit")
def audit(task_id: UUID, db: Session = Depends(get_db)):
    record = db.get(TaskRecord, task_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Task not found")
    runs, events = get_task_audit(db, task_id)
    return {
        "task_id":str(task_id),
        "trace_id":str(record.trace_id),
        "agent_runs":[{"run_id":str(r.run_id),"agent_name":r.agent_name,"status":r.status,"result":r.result,"evidence":r.evidence,"confidence":r.confidence} for r in runs],
        "events":[{"event_id":str(e.event_id),"event_type":e.event_type,"actor":e.actor,"payload":e.payload,"created_at":e.created_at.isoformat()} for e in events]
    }
