from langgraph.graph import END, START, StateGraph

from app.agents.architecture import ArchitectureAgent
from app.agents.requirements import RequirementsAgent
from app.core.config import settings
from app.models.state import EngineeringState
from app.orchestration.checkpoint import get_checkpointer
from app.policies.engine import PolicyEngine
from app.policies.loader import load_policy_config


def build_graph():
    requirements_agent = RequirementsAgent(
        settings.llm_mode,
        settings.llm_model,
        settings.openai_api_key,
    )

    architecture_agent = ArchitectureAgent(
        settings.llm_mode,
        settings.llm_model,
        settings.openai_api_key,
    )

    policy_engine = PolicyEngine(
        load_policy_config(settings.policy_file)
    )

    def requirements(state: EngineeringState) -> dict:
        result = requirements_agent.run(state["user_request"])

        return {
            "requirements": result.result,
            "requirements_run": result.model_dump(),
            "evidence": result.evidence,
            "status": "ANALYZING",
        }

    def requirements_gate(state: EngineeringState) -> dict:
        req = policy_engine.evaluate(
            "REQ-001",
            state,
        )

        audit = policy_engine.evaluate(
            "AUDIT-001",
            state,
        )

        decisions = [req, audit]
        blocked = any(
            not d.passed and d.action == "BLOCK"
            for d in decisions
        )

        return {
            "policy_results": [d.__dict__ for d in decisions],
            "blocked": blocked,
        }

    def route_after_requirements(state: EngineeringState) -> str:
        return "blocked" if state.get("blocked") else "architecture"

    def architecture(state: EngineeringState) -> dict:
        result = architecture_agent.run(state["requirements"])

        return {
            "architecture": result.result,
            "architecture_run": result.model_dump(),
            "evidence": [
                *state.get("evidence", []),
                *result.evidence,
            ],
            "status": "ARCHITECTING",
        }

    def architecture_gate(state: EngineeringState) -> dict:
        decision = policy_engine.evaluate(
            "ARCH-001",
            state,
        )

        return {
            "policy_results": [
                *state.get("policy_results", []),
                decision.__dict__,
            ],
            "blocked": not decision.passed,
            "status": (
                "BLOCKED"
                if not decision.passed
                else "COMPLETED"
            ),
        }

    builder = StateGraph(EngineeringState)

    builder.add_node("requirements", requirements)
    builder.add_node("requirements_gate", requirements_gate)
    builder.add_node("architecture", architecture)
    builder.add_node("architecture_gate", architecture_gate)
    builder.add_node("blocked", lambda _: {"status": "BLOCKED"})

    builder.add_edge(START, "requirements")
    builder.add_edge("requirements", "requirements_gate")

    builder.add_conditional_edges(
        "requirements_gate",
        route_after_requirements,
        {
            "architecture": "architecture",
            "blocked": "blocked",
        },
    )

    builder.add_edge("architecture", "architecture_gate")
    builder.add_edge("architecture_gate", END)
    builder.add_edge("blocked", END)

    return builder.compile(
        checkpointer=get_checkpointer()
    )
