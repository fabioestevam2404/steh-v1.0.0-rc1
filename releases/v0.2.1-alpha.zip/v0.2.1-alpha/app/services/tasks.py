import logging
import time
from uuid import UUID

from sqlalchemy.orm import Session

from app.db.models import TaskRecord
from app.models.contracts import TaskCreate, TaskStatus, utc_now
from app.orchestration.graph import build_graph
from app.services.audit import (
    complete_agent_run,
    fail_agent_run,
    record_event,
    start_agent_run,
)

logger = logging.getLogger("steh.tasks")


def execute_task(
    db: Session,
    task_id: UUID,
    trace_id: UUID,
    payload: TaskCreate,
) -> TaskRecord:
    record = db.get(TaskRecord, task_id)

    if record is None:
        raise ValueError("Task not found")

    record.status = TaskStatus.ANALYZING
    db.commit()

    record_event(
        db,
        task_id,
        trace_id,
        "TASK_STARTED",
        "orchestrator",
        {"request_length": len(payload.request)},
    )

    req_run = start_agent_run(
        db,
        task_id,
        trace_id,
        "requirements_agent",
    )

    arch_run = None
    started = time.perf_counter()

    logger.info(
        "workflow_started",
        extra={
            "task_id": str(task_id),
            "trace_id": str(trace_id),
            "event": "workflow_started",
            "status": "STARTED",
        },
    )

    try:
        graph = build_graph()

        result = graph.invoke(
            {
                "task_id": str(task_id),
                "trace_id": str(trace_id),
                "user_request": payload.request,
                "status": "ANALYZING",
                "evidence": [],
            },
            config={
                "configurable": {
                    "thread_id": str(task_id),
                }
            },
        )

        if result.get("requirements_run"):
            complete_agent_run(
                db,
                req_run,
                result["requirements_run"]["result"],
                result["requirements_run"].get("evidence", []),
                result["requirements_run"].get("confidence", 0.0),
            )

        if result.get("architecture_run"):
            arch_run = start_agent_run(
                db,
                task_id,
                trace_id,
                "architecture_agent",
            )

            complete_agent_run(
                db,
                arch_run,
                result["architecture_run"]["result"],
                result["architecture_run"].get("evidence", []),
                result["architecture_run"].get("confidence", 0.0),
            )

        record.requirements = result.get("requirements")
        record.architecture = result.get("architecture")
        record.status = TaskStatus(result.get("status", "FAILED"))
        record.updated_at = utc_now()

        for decision in result.get("policy_results", []):
            record_event(
                db,
                task_id,
                trace_id,
                "POLICY_DECISION",
                "policy_engine",
                decision,
            )

        final_event = (
            "TASK_COMPLETED"
            if record.status == TaskStatus.COMPLETED
            else "TASK_BLOCKED"
            if record.status == TaskStatus.BLOCKED
            else "TASK_FAILED"
        )

        record_event(
            db,
            task_id,
            trace_id,
            final_event,
            "orchestrator",
            {"status": record.status.value},
        )

        db.commit()
        db.refresh(record)

        logger.info(
            "workflow_completed",
            extra={
                "task_id": str(task_id),
                "trace_id": str(trace_id),
                "event": "workflow_completed",
                "duration_ms": round(
                    (time.perf_counter() - started) * 1000,
                    2,
                ),
                "status": record.status.value,
            },
        )

        return record

    except Exception as exc:
        if req_run.status == "STARTED":
            fail_agent_run(
                db,
                req_run,
                type(exc).__name__,
            )

        if arch_run is not None and arch_run.status == "STARTED":
            fail_agent_run(
                db,
                arch_run,
                type(exc).__name__,
            )

        logger.exception(
            "workflow_failed",
            extra={
                "task_id": str(task_id),
                "trace_id": str(trace_id),
                "event": "workflow_failed",
                "status": "FAILED",
            },
        )

        raise
