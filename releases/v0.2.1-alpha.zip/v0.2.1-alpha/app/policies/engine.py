from dataclasses import dataclass

from app.policies.loader import PolicyConfig, PolicyRule


@dataclass(frozen=True)
class PolicyDecision:
    policy_id: str
    passed: bool
    action: str
    reason: str


def _check(rule: PolicyRule, context: dict) -> bool:
    checks = {
        "requirements_present": bool(context.get("requirements")),
        "evidence_present": bool(context.get("evidence")),
        "architecture_present": bool(context.get("architecture")),
    }

    if rule.check not in checks:
        raise ValueError(f"Unsupported policy check: {rule.check}")

    return checks[rule.check]


class PolicyEngine:
    def __init__(self, config: PolicyConfig) -> None:
        self.config = config

    def evaluate(self, policy_id: str, context: dict) -> PolicyDecision:
        rule = next(
            (item for item in self.config.rules if item.id == policy_id),
            None,
        )

        if rule is None:
            raise KeyError(f"Policy not found: {policy_id}")

        passed = _check(rule, context)

        return PolicyDecision(
            policy_id=rule.id,
            passed=passed,
            action="ALLOW" if passed else rule.action,
            reason=(
                f"{rule.description}: passed"
                if passed
                else f"{rule.description}: failed"
            ),
        )
