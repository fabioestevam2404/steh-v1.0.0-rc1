from app.orchestration.graph import build_graph

def test_two_agent_graph():
    result = build_graph().invoke({
        "task_id":"1","trace_id":"1","user_request":"Crie uma API segura para clientes.",
        "status":"ANALYZING","evidence":[]
    })
    assert result["status"] == "COMPLETED"
    assert result["requirements"]
    assert result["architecture"]
    assert len(result["policy_results"]) == 2
