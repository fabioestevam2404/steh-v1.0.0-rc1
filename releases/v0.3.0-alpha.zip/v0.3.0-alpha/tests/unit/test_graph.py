from app.orchestration.graph import build_graph


def test_graph_reaches_security_human_review_with_stub() -> None:
    graph = build_graph()

    result = graph.invoke(
        {
            "task_id": "test-task",
            "trace_id": "test-trace",
            "user_request": (
                "Crie uma API para gerenciamento seguro de clientes."
            ),
            "status": "ANALYZING",
            "evidence": [],
        },
        config={
            "configurable": {
                "thread_id": "unit-test-security-graph"
            }
        },
    )

    assert result["requirements"]
    assert result["architecture"]
    assert result["security_review"]
    assert result["risk_level"] == "HIGH"
    assert result["status"] == "HUMAN_REVIEW"
