from langgraph.graph import END, START, StateGraph

from app.agents.architecture import ArchitectureAgent
from app.agents.requirements import RequirementsAgent
from app.agents.security import SecurityAgent
from app.core.config import settings
from app.models.state import EngineeringState
from app.orchestration.checkpoint import get_checkpointer
from app.policies.engine import PolicyEngine
from app.policies.loader import load_policy_config


def build_graph():
    requirements_agent = RequirementsAgent(
        settings.llm_mode,
        settings.llm_model,
        settings.openai_api_key,
    )

    architecture_agent = ArchitectureAgent(
        settings.llm_mode,
        settings.llm_model,
        settings.openai_api_key,
    )

    security_agent = SecurityAgent(
        settings.llm_mode,
        settings.llm_model,
        settings.openai_api_key,
    )

    policy_engine = PolicyEngine(
        load_policy_config(settings.policy_file)
    )

    def requirements(state: EngineeringState) -> dict:
        result = requirements_agent.run(state["user_request"])
        return {
            "requirements": result.result,
            "requirements_run": result.model_dump(),
            "evidence": result.evidence,
            "status": "ANALYZING",
        }

    def requirements_gate(state: EngineeringState) -> dict:
        decisions = [
            policy_engine.evaluate("REQ-001", state),
            policy_engine.evaluate("AUDIT-001", state),
        ]
        blocked = any(
            not decision.passed and decision.action == "BLOCK"
            for decision in decisions
        )
        return {
            "policy_results": [d.__dict__ for d in decisions],
            "blocked": blocked,
        }

    def architecture(state: EngineeringState) -> dict:
        result = architecture_agent.run(state["requirements"])
        return {
            "architecture": result.result,
            "architecture_run": result.model_dump(),
            "evidence": [
                *state.get("evidence", []),
                *result.evidence,
            ],
            "status": "ARCHITECTING",
        }

    def architecture_gate(state: EngineeringState) -> dict:
        decision = policy_engine.evaluate("ARCH-001", state)
        return {
            "policy_results": [
                *state.get("policy_results", []),
                decision.__dict__,
            ],
            "blocked": not decision.passed,
        }

    def security(state: EngineeringState) -> dict:
        result = security_agent.run(
            state["requirements"],
            state["architecture"],
        )
        review = result.result
        return {
            "security_review": review,
            "security_run": result.model_dump(),
            "risk_level": review["overall_risk"],
            "evidence": [
                *state.get("evidence", []),
                *result.evidence,
            ],
            "status": "SECURITY_REVIEW",
        }

    def security_gate(state: EngineeringState) -> dict:
        decisions = [
            policy_engine.evaluate("SEC-001", state),
            policy_engine.evaluate("SEC-002", state),
            policy_engine.evaluate("SEC-003", state),
            policy_engine.evaluate("SEC-004", state),
        ]

        hard_block = any(
            not d.passed and d.action == "BLOCK"
            for d in decisions
        )
        human_review = any(
            not d.passed and d.action == "HUMAN_REVIEW"
            for d in decisions
        )

        if hard_block:
            status = "BLOCKED"
        elif human_review:
            status = "HUMAN_REVIEW"
        else:
            status = "COMPLETED"

        return {
            "policy_results": [
                *state.get("policy_results", []),
                *[d.__dict__ for d in decisions],
            ],
            "blocked": hard_block,
            "status": status,
        }

    def route_after_requirements(state: EngineeringState) -> str:
        return "blocked" if state.get("blocked") else "architecture"

    def route_after_architecture(state: EngineeringState) -> str:
        return "blocked" if state.get("blocked") else "security"

    builder = StateGraph(EngineeringState)

    builder.add_node("requirements", requirements)
    builder.add_node("requirements_gate", requirements_gate)
    builder.add_node("architecture", architecture)
    builder.add_node("architecture_gate", architecture_gate)
    builder.add_node("security", security)
    builder.add_node("security_gate", security_gate)
    builder.add_node("blocked", lambda _: {"status": "BLOCKED"})

    builder.add_edge(START, "requirements")
    builder.add_edge("requirements", "requirements_gate")

    builder.add_conditional_edges(
        "requirements_gate",
        route_after_requirements,
        {"architecture": "architecture", "blocked": "blocked"},
    )

    builder.add_edge("architecture", "architecture_gate")

    builder.add_conditional_edges(
        "architecture_gate",
        route_after_architecture,
        {"security": "security", "blocked": "blocked"},
    )

    builder.add_edge("security", "security_gate")
    builder.add_edge("security_gate", END)
    builder.add_edge("blocked", END)

    return builder.compile(checkpointer=get_checkpointer())
