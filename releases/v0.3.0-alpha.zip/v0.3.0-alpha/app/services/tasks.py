import logging
import time
from uuid import UUID

from sqlalchemy.orm import Session

from app.db.models import TaskRecord
from app.models.contracts import TaskCreate, TaskStatus, utc_now
from app.orchestration.graph import build_graph
from app.services.audit import (
    complete_agent_run,
    fail_agent_run,
    record_event,
    start_agent_run,
)
from app.services.security import persist_security_findings

logger = logging.getLogger("steh.tasks")


def execute_task(
    db: Session,
    task_id: UUID,
    trace_id: UUID,
    payload: TaskCreate,
) -> TaskRecord:
    record = db.get(TaskRecord, task_id)
    if record is None:
        raise ValueError("Task not found")

    record.status = TaskStatus.ANALYZING
    db.commit()

    record_event(
        db,
        task_id,
        trace_id,
        "TASK_STARTED",
        "orchestrator",
        {"request_length": len(payload.request)},
    )

    started = time.perf_counter()

    logger.info(
        "workflow_started",
        extra={
            "task_id": str(task_id),
            "trace_id": str(trace_id),
            "event": "workflow_started",
            "status": "STARTED",
        },
    )

    runs = {}

    try:
        runs["requirements_agent"] = start_agent_run(
            db, task_id, trace_id, "requirements_agent"
        )

        graph = build_graph()
        result = graph.invoke(
            {
                "task_id": str(task_id),
                "trace_id": str(trace_id),
                "user_request": payload.request,
                "status": "ANALYZING",
                "evidence": [],
            },
            config={
                "configurable": {
                    "thread_id": str(task_id),
                }
            },
        )

        if result.get("requirements_run"):
            rr = result["requirements_run"]
            complete_agent_run(
                db,
                runs["requirements_agent"],
                rr["result"],
                rr.get("evidence", []),
                rr.get("confidence", 0.0),
            )

        if result.get("architecture_run"):
            runs["architecture_agent"] = start_agent_run(
                db, task_id, trace_id, "architecture_agent"
            )
            ar = result["architecture_run"]
            complete_agent_run(
                db,
                runs["architecture_agent"],
                ar["result"],
                ar.get("evidence", []),
                ar.get("confidence", 0.0),
            )

        if result.get("security_run"):
            runs["security_agent"] = start_agent_run(
                db, task_id, trace_id, "security_agent"
            )
            sr = result["security_run"]
            complete_agent_run(
                db,
                runs["security_agent"],
                sr["result"],
                sr.get("evidence", []),
                sr.get("confidence", 0.0),
            )

        record.requirements = result.get("requirements")
        record.architecture = result.get("architecture")
        record.security_review = result.get("security_review")
        record.risk_level = result.get("risk_level")
        record.status = result.get("status", "FAILED")
        record.updated_at = utc_now()

        if record.security_review:
            persist_security_findings(
                db,
                task_id,
                trace_id,
                record.security_review.get("findings", []),
            )

        for decision in result.get("policy_results", []):
            record_event(
                db,
                task_id,
                trace_id,
                "POLICY_DECISION",
                "policy_engine",
                decision,
            )

        final_event = {
            "COMPLETED": "TASK_COMPLETED",
            "BLOCKED": "TASK_BLOCKED",
            "HUMAN_REVIEW": "TASK_HUMAN_REVIEW",
        }.get(record.status, "TASK_FAILED")

        record_event(
            db,
            task_id,
            trace_id,
            final_event,
            "orchestrator",
            {
                "status": str(record.status),
                "risk_level": record.risk_level,
            },
        )

        db.commit()
        db.refresh(record)

        logger.info(
            "workflow_completed",
            extra={
                "task_id": str(task_id),
                "trace_id": str(trace_id),
                "event": "workflow_completed",
                "duration_ms": round(
                    (time.perf_counter() - started) * 1000,
                    2,
                ),
                "status": str(record.status),
            },
        )

        return record

    except Exception as exc:
        for run in runs.values():
            if run.status == "STARTED":
                fail_agent_run(
                    db,
                    run,
                    type(exc).__name__,
                )

        logger.exception(
            "workflow_failed",
            extra={
                "task_id": str(task_id),
                "trace_id": str(trace_id),
                "event": "workflow_failed",
                "status": "FAILED",
            },
        )
        raise
